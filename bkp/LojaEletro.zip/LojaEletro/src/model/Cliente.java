package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ygor
 */

public class Cliente {
    
    private String nome;
    private String endereco;
    private List<Cliente> clientes;

    public Cliente(String nome, String endereco, List<Cliente> clientes) {
        this.nome = nome;
        this.endereco = endereco;
        this.clientes = new ArrayList<>();
    }
    
    public Cliente() {
        this.nome = "";
        this.endereco = "";
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    @Override
    public String toString() {
        return this.nome;
    }
    
    public void incluir(Cliente cliente) {
        clientes.add(cliente);
    }

    public void remover(Cliente cliente) {
        clientes.remove(cliente);
    }
    
}