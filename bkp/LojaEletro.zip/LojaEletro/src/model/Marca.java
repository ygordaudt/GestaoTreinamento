package model;

/**
 *
 * @author Ygor
 */

public class Marca {
    private String marca;

    
    
    public Marca() {
        this.marca = "";
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
  
 
    
    @Override
    public String toString() {
        return this.marca;
    }
    
}