package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ygor
 */
public class Usuario {
    private String nome;
    private String senha;
    private List<Usuario> usuarios;

    public Usuario(String nome, String senha, List<Usuario> usuarios) {
        this.nome = nome;
        this.senha = senha;
        this.usuarios = new ArrayList<>();
    }
    
    public Usuario() {
        this.nome = "";
        this.senha = "";
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    @Override
    public String toString() {
        return this.nome;
    }

}
