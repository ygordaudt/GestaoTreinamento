package model;

/**
 *
 * @author Ygor
 */

public class Modelo {
    private String modelo;
    private Marca marca;

    
    
    public Modelo() {
        this.modelo = "";
    }

    
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    
    public Marca getMarca() {
        return marca;
    }

    public void setMarca(Marca marca) {
        this.marca = marca;
    }

    
    @Override
    public String toString() {
        return this.modelo;
    }
    
}