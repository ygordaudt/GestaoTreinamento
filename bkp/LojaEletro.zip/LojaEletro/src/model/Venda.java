package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ygor
 */

public class Venda {
    
    private LocalDate dataVenda;
    private boolean vendido;
    private List<Venda> vendas;
    private Aparelho aparelho;
    private Cliente cliente;

    public Venda(LocalDate dataVenda, boolean vendido, List<Venda> vendas, Aparelho aparelho, Cliente cliente) {
        this.dataVenda = dataVenda;
        this.vendido = false;
        this.vendas = new ArrayList<>();
        this.aparelho = aparelho;
        this.cliente = cliente;
    }

    
    
    
    public LocalDate getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(LocalDate dataVenda) {
        this.dataVenda = dataVenda;
    }

    public boolean getVendido() {
        return vendido;
    }

    public void setVendido(boolean vendido) {
        this.vendido = true;
    }

    public List<Venda> getVendas() {
        return vendas;
    }

    public void setVendas(List<Venda> vendas) {
        this.vendas = vendas;
    }

    public Aparelho getAparelho() {
        return aparelho;
    }

    public void setAparelho(Aparelho aparelho) {
        this.aparelho = aparelho;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    @Override
    public String toString() {
        return this.cliente.getNome();
    }
    
    
    
    public boolean verificaGarantia(LocalDate dataVenda) {
        LocalDate dataAtual = LocalDate.now(); // Inicia a variável local como data atual
        LocalDate dataGarantia = dataVenda.plusYears(1); // Inicia a variável local adicionando 1 ano a data da venda
        return dataAtual.isBefore(dataGarantia); // Retorna true caso data atual seja menor que a garantia
    }
    
    
    
    public void incluir(Venda venda) {
        vendas.add(venda);
    }

    public void remover(Venda venda) {
        vendas.remove(venda);
    }
}