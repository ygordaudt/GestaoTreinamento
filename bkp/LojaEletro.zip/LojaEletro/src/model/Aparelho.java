package model;

/**
 *
 * @author Ygor
 */

public class Aparelho {
    
    private String numeroSerie;
    private String defeito;
    private Modelo modelo;

    
    
    public Aparelho(Modelo modelo) {
        this.modelo = modelo;
        this.defeito = "";
    }

    
    
    public String getNumeroSerie() {
        return numeroSerie;
    }

    public void setNumeroSerie(String numeroSerie) {
        this.numeroSerie = numeroSerie;
    }

    public String getDefeito() {
        return defeito;
    }

    public void setDefeito(String defeito) {
        this.defeito = defeito;
    }

    public Modelo getModelo() {
        return modelo;
    }

    public void setModelo(Modelo modelo) {
        this.modelo = modelo;
    }



    
    @Override
    public String toString() {
        return this.modelo.getMarca().toString();
    }
    
    public String getStatus() {
        if (this.defeito == "") {
            return "Bom";
        } else {
            return "Defeito";
        }
    }
  

}