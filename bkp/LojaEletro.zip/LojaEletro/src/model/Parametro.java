package model;

/**
 *
 * @author Ygor
 */
public class Parametro {
    private String diretorioXml;

    public Parametro(String diretorioXml) {
        this.diretorioXml = diretorioXml;
    }

    public Parametro() {
        this.diretorioXml = "";
    }

    public String getDiretorioXml() {
        return diretorioXml;
    }

    public void setDiretorioXml(String diretorioXml) {
        this.diretorioXml = diretorioXml;
    }

    @Override
    public String toString() {
        return this.diretorioXml;
       // return this.diretorioXml.replaceAll("[\\]", "\\"+"\\")
    }
    
   
}
