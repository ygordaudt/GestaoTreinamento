package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ygor
 */

public class TipoDefeito {

    private String TipoDefeito;
    private List<TipoDefeito> tiposDefeito;

    public TipoDefeito(String TipoDefeito, List<TipoDefeito> tiposDefeito) {
        this.TipoDefeito = TipoDefeito;
        this.tiposDefeito = new ArrayList<>();
    }
    
    public TipoDefeito() {
        this.TipoDefeito = "";
    }

    public String getTipoDefeito() {
        return TipoDefeito;
    }

    public void setTipoDefeito(String TipoDefeito) {
        this.TipoDefeito = TipoDefeito;
    }

    public List<TipoDefeito> getTiposDefeito() {
        return tiposDefeito;
    }

    public void setTiposDefeito(List<TipoDefeito> tiposDefeito) {
        this.tiposDefeito = tiposDefeito;
    }

    @Override
    public String toString() {
        return this.TipoDefeito;
    }
    
    
    
    
    
}