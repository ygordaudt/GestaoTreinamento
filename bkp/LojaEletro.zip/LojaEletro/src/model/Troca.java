package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ygor
 */

public class Troca {
    
    private LocalDate dataTroca;
    private List<Troca> trocas;
    private Aparelho aparelhos;
    private Cliente cliente;
    private Venda dataVenda;
    private TipoDefeito tipoDefeito;

    
    
    
    public Troca(LocalDate dataTroca, List<Troca> trocas, Aparelho aparelhos, Cliente cliente, Venda dataVenda, TipoDefeito tipoDefeito) {
        this.dataTroca = dataTroca;
        this.trocas = new ArrayList<>();
        this.aparelhos = aparelhos;
        this.cliente = cliente;
        this.dataVenda = dataVenda;
        this.tipoDefeito = tipoDefeito;
    }

    
    
    
    public Aparelho getAparelhos() {
        return aparelhos;
    }

    public void setAparelhos(Aparelho aparelhos) {
        this.aparelhos = aparelhos;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Venda getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(Venda dataVenda) {
        this.dataVenda = dataVenda;
    }

    public LocalDate getDataTroca() {
        return dataTroca;
    }

    public void setDataTroca(LocalDate dataTroca) {
        this.dataTroca = dataTroca;
    }

    public TipoDefeito getTipoDefeito() {
        return tipoDefeito;
    }

    public void setTipoDefeito(TipoDefeito tipoDefeito) {
        this.tipoDefeito = tipoDefeito;
    }

    
    
    @Override
    public String toString() {
        return this.aparelhos.getNumeroSerie();
    }
    
    
    
    public void incluir(Troca troca) {
        trocas.add(troca);
    }

    public void remover(Troca troca) {
        trocas.remove(troca);
    }

}