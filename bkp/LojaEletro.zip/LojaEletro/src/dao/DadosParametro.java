package dao;

import java.util.ArrayList;
import java.util.List;
import model.Parametro;

public class DadosParametro implements Dados {
    private static List<Parametro> parametros = new ArrayList();
    private static final String nomeArquivo = "\\Parametro.xml"; 

    @Override
    public void incluir(Object objeto) throws Exception {
        Parametro parametro = (Parametro) objeto;
        parametros.add(parametro);
        Xml.gravaXml(nomeArquivo, parametros);
    }

    @Override
    public void remover(Object objeto) throws Exception {
        Parametro parametro = (Parametro) objeto;
        parametros.remove(parametro);
        Xml.gravaXml(nomeArquivo, parametros);
    }

    @Override
    public List getList() throws Exception{
        parametros = (List<Parametro>) Xml.leXml(nomeArquivo);
        return parametros;
    }
    
}