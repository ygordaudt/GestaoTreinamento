package dao;

import model.Aparelho;
import java.util.ArrayList;
import java.util.List;

public class DadosAparelho implements Dados{
    private static List<Aparelho> aparelhos = new ArrayList();
    private static final String nomeArquivo = "\\Aparelhos.xml";

    @Override
    public void incluir(Object objeto) throws Exception {
        Aparelho aparelho = (Aparelho) objeto;
        aparelhos.add(aparelho);
        Xml.gravaXml(nomeArquivo, aparelhos);
    }

    @Override
    public void remover(Object objeto) throws Exception {
        Aparelho aparelho = (Aparelho) objeto;
        aparelhos.remove(aparelho);
        Xml.gravaXml(nomeArquivo, aparelhos);
    }

    @Override
    public List<Aparelho> getList() throws Exception{
        aparelhos = (List<Aparelho>) Xml.leXml(nomeArquivo);
        return aparelhos;
    }

}