package dao;

import model.Marca;
import java.util.ArrayList;
import java.util.List;

public class DadosMarca implements Dados{
    private static List<Marca> marcas = new ArrayList();
    private static final String nomeArquivo = "\\Marcas.xml";

    @Override
    public void incluir(Object objeto) throws Exception {
        Marca marca = (Marca) objeto;
        marcas.add(marca);
        Xml.gravaXml(nomeArquivo, marcas);
    }

    @Override
    public void remover(Object objeto) throws Exception {
        Marca marca = (Marca) objeto;
        marcas.remove(marca);
        Xml.gravaXml(nomeArquivo, marcas);
    }

    @Override
    public List<Marca> getList() throws Exception{
        marcas = (List<Marca>) Xml.leXml(nomeArquivo);
        return marcas;
    }

}