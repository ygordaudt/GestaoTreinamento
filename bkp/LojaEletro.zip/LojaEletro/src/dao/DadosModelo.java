package dao;

import model.Modelo;
import java.util.ArrayList;
import java.util.List;

public class DadosModelo implements Dados{
    private static List<Modelo> modelos = new ArrayList();
    private static final String nomeArquivo = "\\Modelos.xml";

    @Override
    public void incluir(Object objeto) throws Exception {
        Modelo modelo = (Modelo) objeto;
        modelos.add(modelo);
        Xml.gravaXml(nomeArquivo, modelos);
    }

    @Override
    public void remover(Object objeto) throws Exception {
        Modelo modelo = (Modelo) objeto;
        modelos.remove(modelo);
        Xml.gravaXml(nomeArquivo, modelos);
    }

    @Override
    public List<Modelo> getList() throws Exception{
        modelos = (List<Modelo>) Xml.leXml(nomeArquivo);
        return modelos;
    }

}