package dao;

import model.Usuario;
import java.util.ArrayList;
import java.util.List;

public class DadosUsuario implements Dados {
    private static List<Usuario> usuarios = new ArrayList();
    private static final String nomeArquivo = "\\Usuarios.xml"; 

    @Override
    public void incluir(Object objeto) throws Exception {
        Usuario usuario = (Usuario) objeto;
        usuarios.add(usuario);
        Xml.gravaXml(nomeArquivo, usuarios);
    }

    @Override
    public void remover(Object objeto) throws Exception {
        Usuario usuario = (Usuario) objeto;
        usuarios.remove(usuario);
        Xml.gravaXml(nomeArquivo, usuarios);
    }

    @Override
    public List getList() throws Exception{
        usuarios = (List<Usuario>) Xml.leXml(nomeArquivo);
        return usuarios;
    }
    
}