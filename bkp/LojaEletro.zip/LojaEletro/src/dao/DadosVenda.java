package dao;

import model.Venda;
import java.util.ArrayList;
import java.util.List;

public class DadosVenda implements Dados {
    private static List<Venda> vendas = new ArrayList();
    private static final String nomeArquivo = "\\Vendas.xml";
    
    @Override
    public void incluir(Object objeto) throws Exception {
        Venda venda = (Venda) objeto;
        vendas.add(venda);
        Xml.gravaXml(nomeArquivo, vendas);
    }

    public void alterar(Object objeto) throws Exception {
        Xml.gravaXml(nomeArquivo, vendas);
    }

    @Override
    public void remover(Object objeto) throws Exception {
        Venda venda = (Venda) objeto;
        vendas.remove(venda);
        Xml.gravaXml(nomeArquivo, vendas);
    }

    @Override
    public List getList() throws Exception{
        vendas = (List<Venda>) Xml.leXml(nomeArquivo);
        return vendas;
    }
}