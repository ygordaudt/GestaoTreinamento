package dao;

import model.TipoDefeito;
import java.util.ArrayList;
import java.util.List;

public class DadosTipoDefeito implements Dados{
    private static List<TipoDefeito> tiposDefeito = new ArrayList();
    private static final String nomeArquivo = "\\TiposDefeito.xml";

    @Override
    public void incluir(Object objeto) throws Exception {
        TipoDefeito tipoDefeito = (TipoDefeito) objeto;
        tiposDefeito.add(tipoDefeito);
        Xml.gravaXml(nomeArquivo, tiposDefeito);
    }

    @Override
    public void remover(Object objeto) throws Exception {
        TipoDefeito tipoDefeito = (TipoDefeito) objeto;
        tiposDefeito.remove(tipoDefeito);
        Xml.gravaXml(nomeArquivo, tiposDefeito);
    }

    @Override
    public List<TipoDefeito> getList() throws Exception{
        tiposDefeito = (List<TipoDefeito>) Xml.leXml(nomeArquivo);
        return tiposDefeito;
    }

}