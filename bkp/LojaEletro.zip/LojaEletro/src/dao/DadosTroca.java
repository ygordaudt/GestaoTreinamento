package dao;

import model.Troca;
import java.util.ArrayList;
import java.util.List;

public class DadosTroca implements Dados {
    private static List<Troca> trocas = new ArrayList();
    private static final String nomeArquivo = "\\Trocas.xml";
    
    @Override
    public void incluir(Object objeto) throws Exception {
        Troca troca = (Troca) objeto;
        trocas.add(troca);
        Xml.gravaXml(nomeArquivo, trocas);
    }

    public void alterar(Object objeto) throws Exception {
        Xml.gravaXml(nomeArquivo, trocas);
    }

    @Override
    public void remover(Object objeto) throws Exception {
        Troca troca = (Troca) objeto;
        trocas.remove(troca);
        Xml.gravaXml(nomeArquivo, trocas);
    }

    @Override
    public List getList() throws Exception{
        trocas = (List<Troca>) Xml.leXml(nomeArquivo);
        return trocas;
    }
}