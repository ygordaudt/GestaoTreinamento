package dao;

import model.Cliente;
import java.util.ArrayList;
import java.util.List;

public class DadosCliente implements Dados {
    private static List<Cliente> clientes = new ArrayList();
    private static final String nomeArquivo = "\\Clientes.xml"; 

    @Override
    public void incluir(Object objeto) throws Exception {
        Cliente cliente = (Cliente) objeto;
        clientes.add(cliente);
        Xml.gravaXml(nomeArquivo, clientes);
    }

    @Override
    public void remover(Object objeto) throws Exception {
        Cliente cliente = (Cliente) objeto;
        clientes.remove(cliente);
        Xml.gravaXml(nomeArquivo, clientes);
    }

    @Override
    public List getList() throws Exception{
        clientes = (List<Cliente>) Xml.leXml(nomeArquivo);
        return clientes;
    }
    
}