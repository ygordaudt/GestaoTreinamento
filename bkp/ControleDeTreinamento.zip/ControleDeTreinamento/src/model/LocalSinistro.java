package model;

/**
 *
 * @author Ygor
 */
public enum LocalSinistro {
    INTERNO,
    EXTERNO;
}